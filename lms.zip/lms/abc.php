<form method="POST">
	
	<input type="text" name="" placeholder="Enter Name" required="">

	<input type="email" name="" placeholder="Enter email" required="">

	<input type="text" name="" placeholder="Enter password" required="">

	<input type="file" name="" required="">

	<input type="date" name="" required="">

	<input type="submit" value="Register"> 
</form>

