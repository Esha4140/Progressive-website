<?php include 'header.php';

$ID = $_GET['ID'];
$Qry = mysqli_query($con, "SELECT * FROM blogs WHERE ID = '$ID'");
$Blog = mysqli_fetch_array($Qry);
?>

<div class="container mt-5" style="min-height: 75vh;">
    <div class="row">

        <div class="offset-sm-2 col-sm-8">
            <div class="card" >
                <img src="assets/images/<?=$Blog['banner']?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?=$Blog['title']?></h5>
                    <p class="card-text"><?=$Blog['content']?></p>
                    <small>
                    <?=$Blog['date_created']?>
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>