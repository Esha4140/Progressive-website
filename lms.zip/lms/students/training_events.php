<div class="row" style="margin-top: -12px !important">
    <div style="background: #201D1D; padding-right: 15px; height: 45px; line-height: 45px;">
        <div class="col-sm-4"></div>
        <div class="col-sm-4" style="color: green; font-weight: bold;"><?= @$_GET['msg'] ?></div>
        <div class="col-sm-4"><span class="title pull-right">Training Events</span></div>
    </div>
</div>
<div class="row" style="margin-top: 5%">
    <div class="col-sm-12">
        <table id="table" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Event Name</th>
                    <th>Type</th>
                    <th>Start Date</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Venue</th>
                    <th>Joining Link</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                $result = mysqli_query($con, "SELECT * FROM trainingevents");

                while ($row = mysqli_fetch_array($result)) {
                    echo "<tr>
                         <td>$i</td>
                         <td>$row[EventName]</td>
                         <td>$row[EventType]</td>
                         <td>$row[EventDate]</td>
                         <td>$row[StartTime]</td>
                         <td>$row[EndTime]</td>
                         <td>$row[VenueID]</td>
                         <td>$row[JoinLink]</td>
                 </tr>";
                    $i++;
                } ?>

            </tbody>
        </table>
    </div>
</div>