<?php 
	
	$con = mysqli_connect("localhost", "root", "", "lms_db");
	session_start();
?>